### Need to run:

8-tier2-a-unoptimized_ALL
8-tier2-i-unoptimized_ALL
8-tier2-u-unoptimized_ALL

8-tier3-a-unoptimized_24
8-tier3-i-unoptimized_19
8-tier3-u-unoptimized_ALL